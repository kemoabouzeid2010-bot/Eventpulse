const mongoose = require('mongoose');
const eventSchema = new mongoose.Schema({
  title:{type:String,required:true,trim:true,index:true},
  description:{type:String,required:true,trim:true},
  location:{type:String,required:true,trim:true},
  startDate:{type:Date,required:true,index:true},
  endDate:{type:Date,required:true},
  capacity:{type:Number,required:true,min:1},
  registeredCount:{type:Number,default:0,min:0},
  category:{type:mongoose.Schema.Types.ObjectId,ref:'Category',required:true,index:true},
  organizer:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},
  imageUrl:{type:String,trim:true},
  status:{type:String,enum:['draft','published','cancelled'],default:'published',index:true}
},{timestamps:true});
eventSchema.index({title:'text',description:'text',location:'text'});
eventSchema.virtual('spotsLeft').get(function(){return Math.max(0,this.capacity-this.registeredCount);});
eventSchema.set('toJSON',{virtuals:true});
module.exports=mongoose.model('Event',eventSchema);
