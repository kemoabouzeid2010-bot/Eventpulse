const mongoose = require('mongoose');
let cached = global.__eventpulse_mongoose;
if (!cached) cached = global.__eventpulse_mongoose = { conn: null, promise: null };
module.exports = async function connectDB() {
  if (cached.conn) return cached.conn;
  if (!process.env.MONGO_URI) throw new Error('MONGO_URI is not configured');
  if (!cached.promise) cached.promise = mongoose.connect(process.env.MONGO_URI).then(m => m.connection);
  cached.conn = await cached.promise;
  return cached.conn;
};
