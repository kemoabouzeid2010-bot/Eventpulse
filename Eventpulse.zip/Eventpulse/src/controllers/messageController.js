const Message=require('../models/Message');
exports.create=async(req,res,next)=>{try{const m=await Message.create(req.body);res.status(201).json({success:true,data:m})}catch(e){next(e)}};
exports.list=async(req,res,next)=>{try{const data=await Message.find().sort({createdAt:-1});res.json({success:true,data})}catch(e){next(e)}};
exports.read=async(req,res,next)=>{try{const m=await Message.findByIdAndUpdate(req.params.id,{read:true},{new:true});if(!m)return res.status(404).json({success:false,message:'Message not found'});res.json({success:true,data:m})}catch(e){next(e)}};
