const Category=require('../models/Category');
exports.list=async(req,res,next)=>{try{res.json({success:true,data:await Category.find().sort({name:1})})}catch(e){next(e)}};
exports.create=async(req,res,next)=>{try{const c=await Category.create(req.body);res.status(201).json({success:true,data:c})}catch(e){next(e)}};
exports.update=async(req,res,next)=>{try{const c=await Category.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});if(!c)return res.status(404).json({success:false,message:'Category not found'});res.json({success:true,data:c})}catch(e){next(e)}};
exports.remove=async(req,res,next)=>{try{const c=await Category.findByIdAndDelete(req.params.id);if(!c)return res.status(404).json({success:false,message:'Category not found'});res.json({success:true,message:'Category deleted'})}catch(e){next(e)}};
