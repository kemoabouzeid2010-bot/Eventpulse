require('dotenv').config();
const express=require('express');const cors=require('cors');const helmet=require('helmet');const morgan=require('morgan');const rateLimit=require('express-rate-limit');const connectDB=require('./config/db');const {notFound,errorHandler}=require('./middleware/error');
const app=express();
app.set('trust proxy',1);app.use(helmet());app.use(cors({origin:process.env.CORS_ORIGIN||'*'}));app.use(express.json({limit:'1mb'}));app.use(morgan('combined'));app.use(rateLimit({windowMs:15*60*1000,max:300,standardHeaders:true,legacyHeaders:false}));
app.get('/',(req,res)=>res.json({success:true,name:'EventPulse API',version:'1.0.0',status:'ok',docs:{auth:'/api/auth',events:'/api/events',categories:'/api/categories',messages:'/api/messages'}}));
app.get('/health',async(req,res)=>{try{await connectDB();res.json({success:true,status:'healthy'})}catch(e){res.status(503).json({success:false,status:'unhealthy',message:'Database unavailable'})}});
app.use('/api/auth',require('./routes/auth'));app.use('/api/events',require('./routes/events'));app.use('/api/categories',require('./routes/categories'));app.use('/api/messages',require('./routes/messages'));
app.use(notFound);app.use(errorHandler);module.exports=app;
