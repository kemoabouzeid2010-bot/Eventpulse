const jwt = require('jsonwebtoken');
const User = require('../models/User');
async function protect(req,res,next){
  try {
    const header=req.headers.authorization||'';
    if(!header.startsWith('Bearer ')) return res.status(401).json({success:false,message:'Authentication required'});
    const token=header.slice(7);
    const payload=jwt.verify(token,process.env.JWT_SECRET);
    const user=await User.findById(payload.id);
    if(!user) return res.status(401).json({success:false,message:'User no longer exists'});
    req.user=user; next();
  } catch(e){ return res.status(401).json({success:false,message:'Invalid or expired token'}); }
}
function authorize(...roles){return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({success:false,message:'Forbidden'});}
module.exports={protect,authorize};
