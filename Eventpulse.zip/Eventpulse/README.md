# EventPulse API

REST API for the EventPulse final project. It includes JWT authentication, role-based authorization, MongoDB/Mongoose models, event search/filter/sort/pagination, registration and capacity management, categories, and contact messages.

## Stack
- Node.js + Express
- MongoDB + Mongoose
- JWT + bcryptjs
- Helmet, CORS, rate limiting
- Vercel serverless deployment

## Local setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your MongoDB connection string in `MONGO_URI` and set a strong `JWT_SECRET`.
5. Run `npm run dev`.
6. Open `http://localhost:3000/`.

## Main endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/events`
- `GET /api/events/:id`
- `POST /api/events`
- `PATCH /api/events/:id`
- `DELETE /api/events/:id`
- `POST /api/events/:id/register`
- `DELETE /api/events/:id/register`
- `GET /api/events/registrations/me`
- `GET /api/categories`
- `POST /api/categories` (admin)
- `POST /api/messages`
- `GET /api/messages` (admin)

## Event query examples
`GET /api/events?search=workshop&category=<id>&page=1&limit=10&sort=startDate&order=asc`

## Vercel
The included `api/index.js` and `vercel.json` configure the Express app for Vercel. Add `MONGO_URI`, `JWT_SECRET`, `JWT_EXPIRES_IN`, and `CORS_ORIGIN` as Vercel Environment Variables before testing the deployed API.

Never commit `.env` or real secrets.
