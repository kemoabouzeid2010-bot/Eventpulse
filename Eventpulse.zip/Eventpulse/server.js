require('dotenv').config();
const app = require('./src/app');
const connectDB = require('./src/config/db');
const PORT = process.env.PORT || 3000;
(async () => {
  await connectDB();
  app.listen(PORT, () => console.log(`EventPulse API running on port ${PORT}`));
})().catch(err => { console.error(err); process.exit(1); });
